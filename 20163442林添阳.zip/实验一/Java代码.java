//FileRW.java

import java.io.*;
import java.util.*;

public class FileRW
{

	public static int NUMBER = 3;
	public static void main(String[] args)
	{
		Person[] people = new Person[NUMBER];

		String[] field = new String[4];

		for(int i = 0; i < 4; i++)
		{
			field[i] = "";
		}

		try
		{

			int fieldcount = 0;


			BufferedReader stdin =
				new BufferedReader(new InputStreamReader(System.in));
			for(int i = 0; i < NUMBER; i++)
			{
				fieldcount = 0;
				System.out.println("The number " + (i + 1) + " person");
				System.out.println("Enter name,age,salary,married(optional), please separate fields by ':'");

				String personstr = stdin.readLine();

				StringTokenizer st = new StringTokenizer(personstr,":");
		
				while (st.hasMoreTokens())
				{
					field[fieldcount] = st.nextToken();
					fieldcount++;
				}

				if(field[3] != "")
				{
					people[i] = new Person(field[0], Integer.parseInt(field[1]),
						Double.parseDouble(field[2]), field[3]);

					field[3] = "";
				}

				else
				{
					people[i] = new Person(field[0], Integer.parseInt(field[1]),
						Double.parseDouble(field[2]));
				}
			}


			PrintWriter out = new PrintWriter( new BufferedWriter(new
				FileWriter("people.dat")));
			writeData(people, out);

			out.close();


			BufferedReader in = new BufferedReader(new
				FileReader("people.dat"));
			Person[] inPeople = readData(in);

			in.close();


			for (int i = 0; i < inPeople.length; i++)
				System.out.println(inPeople[i]);
		}
		catch(IOException exception)
		{
			System.err.println("IOException");
		}
	}


	static void writeData(Person[] p, PrintWriter out) 
		throws IOException
	{

		out.println(p.length);
		for (int i = 0; i < p.length; i++)
			p[i].writeData(out);
	}

	static Person[] readData(BufferedReader in)
		throws IOException
	{

		int n = Integer.parseInt(in.readLine());

		Person[] p = new Person[n];
		for (int i = 0; i < n; i++)
		{
			p[i] = new Person();
			p[i].readData(in);
		}
		return p;
	}
}

class Person
{
	private String name;
	private int age;
	private double salary;
	private String married;

	public Person()
	{
	}

	public Person(String n, int a, double s)
	{
		name = n;
		age = a;
		salary = s;
		married = "F";
	}

	public Person(String n, int a, double s, String m)
	{
		name = n;
		age = a;
		salary = s;
		married = m;
	}

	public String getName()
	{
		return name;
	}

	public int getAge()
	{
		return age;
	}

	public double getSalary()
	{
		return salary;
	}

	public String getMarried()
	{
		return married;
	}


	public String toString()
	{
		return getClass().getName() + "[name=" + name
			+ ",age=" + age
			+ ",salary=" + salary
			+ ",married=" + married
			+ "]";
	}


	public void writeData(PrintWriter out) throws IOException
	{

		out.println(name + ":"
			+ age + ":"
			+ salary + ":"
			+ married);
	}


	public void readData(BufferedReader in) throws IOException
	{
		String s = in.readLine();
		StringTokenizer t = new StringTokenizer(s, ":");
		name = t.nextToken();
		age = Integer.parseInt(t.nextToken());
		salary = Double.parseDouble(t.nextToken());
		married = t.nextToken();
	}
}